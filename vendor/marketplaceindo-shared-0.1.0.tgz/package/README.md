# @marketplaceindo/shared

Sumber kebenaran tunggal untuk **schema Zod, tipe TypeScript, dan konstanta** yang dipakai bersama oleh repo backend (NestJS) dan frontend (Nuxt) MarketIndonesia. Tidak berisi logika bisnis. Dependency runtime hanya `zod` (peer dependency).

Dokumen penting:

- [docs/PLAN-SHARED.md](docs/PLAN-SHARED.md) — planning fase, kebijakan versioning, runbook perubahan schema.
- [docs/API-CONTRACT.md](docs/API-CONTRACT.md) — **master copy** kontrak API (salinan di repo konsumen mengikuti file ini).

## Install (di repo konsumen)

Package di-publish privat ke **GitHub Packages**. Di repo backend/frontend:

1. Salin [`.npmrc.example`](.npmrc.example) sebagai `.npmrc`, lalu set env `GITHUB_TOKEN` (PAT dengan scope `read:packages`).
2. Install dengan **versi pasti** (tanpa `^`/`~`):

```sh
npm install --save-exact @marketplaceindo/shared@0.1.0 zod
```

`zod` v4 adalah peer dependency dan harus di-install sendiri oleh konsumen (satu instance Zod).

## Development

```sh
npm install
npm run typecheck   # tsc --noEmit (strict)
npm test            # vitest
npm run build       # tsup → dist/ (ESM + CJS + .d.ts)
```

## Rilis

1. Bump `version` di `package.json` + tambah entri `CHANGELOG.md`.
2. Commit, lalu buat tag `vX.Y.Z` (harus sama dengan version) dan push tag.
3. Workflow [publish.yml](.github/workflows/publish.yml) menjalankan typecheck + test + build lalu `npm publish` ke GitHub Packages.

Kebijakan semver dan runbook perubahan schema: lihat [docs/PLAN-SHARED.md](docs/PLAN-SHARED.md).
