# Changelog

Semua perubahan berarti pada package ini dicatat di sini, per rilis.
Format tiap entri: apa yang berubah + apakah konsumen (backend/frontend) perlu penyesuaian.

## [Unreleased]

## [0.1.0] — 2026-07-14

Fase 1 — definisi schema lengkap. Rilis ini membuka Fase 0 repo backend & frontend.

- **Block content**: discriminated union `blockSchema` dengan 29 tipe section (inti 12, bisnis & jasa 4, katalog 4, kuliner 4, otomotif 2, fungsional 3) + sub-schema `linkSchema`, `ctaSchema`, `imageRefSchema`, `menuItemSchema`, `openingHoursItemSchema`.
- **Styling**: `sectionStyleSchema` (partial; font, warna hex ter-regex, alignment, paddingY) dan `tenantThemeSchema` (token global).
- **Collection**: `vehicleSchema`/`productSchema` + varian `Input`/`Update` + schema query filter (coerce angka dari query string).
- **Onboarding**: `wizardAnswersSchema` (businessName, businessType, address, whatsapp, openingHours, highlights 1–3, tagline).
- **DTO API**: request/response semua endpoint API-CONTRACT.md (auth, tenants, templates, pages/sections/blocks, media, leads, billing, render, internal revalidate) + `pageSeoSchema` + `apiErrorSchema` (§1.4).
- **Konstanta**: `TENANT_STATUSES`, `SUBSCRIPTION_STATUSES`, `INVOICE_STATUSES`, `BUSINESS_TYPES`, katalog `ERROR_CODES` + `ERROR_HTTP_STATUS` (§12), `SUBDOMAIN_BLACKLIST` + `isReservedSubdomain()`, `PLANS` (tahunan Rp300rb hero / bulanan Rp30rb QRIS+e-wallet), `PLAN_LIMITS`, `ALLOWED_MEDIA_MIME_TYPES`.
- **Catatan angka awal (boleh disesuaikan di rilis berikutnya)**: kuota `PLAN_LIMITS` (item koleksi 50/200, storage 500/2048 MB, upload 5/10 MB, halaman 10/20), `MAX_DRAFT_TENANTS_PER_USER = 3`, isi blacklist subdomain di luar 5 entri wajib kontrak.
- 151 unit test (kasus valid + invalid per schema, termasuk seluruh 29 tipe block dan regex warna/WA/subdomain).
- **Konsumen:** install `@marketplaceindo/shared@0.1.0` (versi pasti) + peer `zod` v4. Ini rilis pertama yang layak dikonsumsi.

## [0.0.1] — 2026-07-14

Rilis uji pipeline (Fase 0). Belum berisi schema — hanya scaffold build & publish.

- Setup build tsup (ESM + CJS + `.d.ts`), TypeScript strict, vitest.
- Konfigurasi publish ke GitHub Packages + workflow CI (typecheck/test di PR, publish saat tag `v*`).
- **Konsumen:** belum perlu install versi ini; tunggu `v0.1.0` (Fase 1).
